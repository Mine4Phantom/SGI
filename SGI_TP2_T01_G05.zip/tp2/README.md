# SGI 2022/2022 - Project 1

# Group TxGy

| Name             | Number    |
| ---------------- | --------- |
| Miguel Neves     | 201608657 |
| Pedro Coelho     | 201806802 |


## Project Notes

(Place here the main highlights and difficulties of your project)

## Screenshots

### 1 - Overall View
(brief description)
![Screenshots 1](tp1/screenshots/img1.png)

### 2 - ....
(add other screenshots here)

